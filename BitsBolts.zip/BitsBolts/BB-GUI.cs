﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BitsBolts
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void LSU_Click(object sender, EventArgs e)
        {

        }

        private void DAN_Click(object sender, EventArgs e)
        {
            this.dat1.Visible = true; // show the frequency of rats captured
            this.dat3.Visible = true; // show the paths threaded
            this.Def.Visible = false; // hide the default picture
            this.rat_live.Visible = false; //hide rat picture
            // renders the chart
            int index = this.dat1.Series["Frequency"].Points.AddXY(1,34);
            this.dat1.Series["Frequency"].Points[index].AxisLabel = "FEB";
            int index1 = this.dat1.Series["Frequency"].Points.AddXY(2, 37);
            this.dat1.Series["Frequency"].Points[index1].AxisLabel = "MAR";
            int index2 = this.dat1.Series["Frequency"].Points.AddXY(3, 25);
            this.dat1.Series["Frequency"].Points[index2].AxisLabel = "APR";
            int index3 = this.dat1.Series["Frequency"].Points.AddXY(4, 17);
            this.dat1.Series["Frequency"].Points[index3].AxisLabel = "MAY";
        }

        private void LSU_Click_1(object sender, EventArgs e)
        {
            // THIS IS THE DUMMY BUTTON THAT REPRESENTS A RAT BEING DETECTED
            this.dat1.Visible = false;
            this.dat3.Visible = false;
            this.Def.Visible = false;
            this.LIVE_STATUS.Visible = true;
            this.rat_live.Visible = true;

            // AFTER DETECTION CAN AUTORESET OR CAN MAKE IT AS A FORM CLICK EVENT TO RETURN TO DEFAULT I CAN HANDLE ON THAT DAY
        }

        private void IMD_Click(object sender, EventArgs e)
        {
            //DUMMY FOLDER LOCATION
            System.Diagnostics.Process.Start("c:\\");
        }

    }
}
