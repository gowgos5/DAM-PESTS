﻿namespace BitsBolts
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.LSU = new System.Windows.Forms.Button();
            this.IMD = new System.Windows.Forms.Button();
            this.DAN = new System.Windows.Forms.Button();
            this.dat1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Def = new System.Windows.Forms.PictureBox();
            this.rat_live = new System.Windows.Forms.PictureBox();
            this.dat3 = new System.Windows.Forms.PictureBox();
            this.LIVE_STATUS = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dat1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Def)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rat_live)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dat3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LIVE_STATUS)).BeginInit();
            this.SuspendLayout();
            // 
            // LSU
            // 
            this.LSU.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LSU.Location = new System.Drawing.Point(927, 32);
            this.LSU.Name = "LSU";
            this.LSU.Size = new System.Drawing.Size(309, 86);
            this.LSU.TabIndex = 1;
            this.LSU.Text = "Live Status Update";
            this.LSU.UseVisualStyleBackColor = true;
            this.LSU.Click += new System.EventHandler(this.LSU_Click_1);
            // 
            // IMD
            // 
            this.IMD.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IMD.Location = new System.Drawing.Point(927, 155);
            this.IMD.Name = "IMD";
            this.IMD.Size = new System.Drawing.Size(309, 86);
            this.IMD.TabIndex = 2;
            this.IMD.Text = "Image Database";
            this.IMD.UseVisualStyleBackColor = true;
            this.IMD.Click += new System.EventHandler(this.IMD_Click);
            // 
            // DAN
            // 
            this.DAN.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DAN.Location = new System.Drawing.Point(927, 282);
            this.DAN.Name = "DAN";
            this.DAN.Size = new System.Drawing.Size(309, 86);
            this.DAN.TabIndex = 3;
            this.DAN.Text = "Data Analysis";
            this.DAN.UseVisualStyleBackColor = true;
            this.DAN.Click += new System.EventHandler(this.DAN_Click);
            // 
            // dat1
            // 
            chartArea2.Name = "ChartArea1";
            this.dat1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.dat1.Legends.Add(legend2);
            this.dat1.Location = new System.Drawing.Point(889, 425);
            this.dat1.Name = "dat1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Frequency";
            this.dat1.Series.Add(series2);
            this.dat1.Size = new System.Drawing.Size(413, 294);
            this.dat1.TabIndex = 4;
            this.dat1.Text = "Data Analysis";
            this.dat1.Visible = false;
            // 
            // Def
            // 
            this.Def.Image = global::BitsBolts.Properties.Resources.DEFAULT;
            this.Def.Location = new System.Drawing.Point(12, 14);
            this.Def.Name = "Def";
            this.Def.Size = new System.Drawing.Size(804, 730);
            this.Def.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Def.TabIndex = 7;
            this.Def.TabStop = false;
            // 
            // rat_live
            // 
            this.rat_live.Image = global::BitsBolts.Properties.Resources.rat_live;
            this.rat_live.Location = new System.Drawing.Point(838, 404);
            this.rat_live.Name = "rat_live";
            this.rat_live.Size = new System.Drawing.Size(482, 340);
            this.rat_live.TabIndex = 6;
            this.rat_live.TabStop = false;
            this.rat_live.Visible = false;
            // 
            // dat3
            // 
            this.dat3.Image = global::BitsBolts.Properties.Resources.PASTCOLLECT;
            this.dat3.Location = new System.Drawing.Point(12, 14);
            this.dat3.Name = "dat3";
            this.dat3.Size = new System.Drawing.Size(804, 730);
            this.dat3.TabIndex = 5;
            this.dat3.TabStop = false;
            this.dat3.Visible = false;
            // 
            // LIVE_STATUS
            // 
            this.LIVE_STATUS.Image = global::BitsBolts.Properties.Resources.BASE;
            this.LIVE_STATUS.Location = new System.Drawing.Point(12, 14);
            this.LIVE_STATUS.Name = "LIVE_STATUS";
            this.LIVE_STATUS.Size = new System.Drawing.Size(804, 730);
            this.LIVE_STATUS.TabIndex = 0;
            this.LIVE_STATUS.TabStop = false;
            this.LIVE_STATUS.Visible = false;
            this.LIVE_STATUS.WaitOnLoad = true;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(1332, 756);
            this.Controls.Add(this.Def);
            this.Controls.Add(this.rat_live);
            this.Controls.Add(this.dat3);
            this.Controls.Add(this.dat1);
            this.Controls.Add(this.DAN);
            this.Controls.Add(this.IMD);
            this.Controls.Add(this.LSU);
            this.Controls.Add(this.LIVE_STATUS);
            this.Name = "Form1";
            this.Text = "ELAN";
            ((System.ComponentModel.ISupportInitialize)(this.dat1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Def)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rat_live)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dat3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LIVE_STATUS)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox LIVE_STATUS;
        private System.Windows.Forms.Button LSU;
        private System.Windows.Forms.Button IMD;
        private System.Windows.Forms.Button DAN;
        private System.Windows.Forms.DataVisualization.Charting.Chart dat1;
        private System.Windows.Forms.PictureBox dat3;
        private System.Windows.Forms.PictureBox rat_live;
        private System.Windows.Forms.PictureBox Def;
    }
}

